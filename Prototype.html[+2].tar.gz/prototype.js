var map;
var infowindow;

var allVulns = ["None", "WEP", "WPA"];
var allDefs = ["None", "Firewall1", "Firewall2"];
var allPlaces = {};


function Entity(offVulns,defVulns,offDefs,defDefs){
	this.offVulns = offVulns || [];
	this.defVulns = defVulns || [];
	this.offDefs = offDefs || [];
	this.defDefs = defDefs || [];
}

var player = new Entity(allVulns.slice(0,2), [], allDefs.slice(0,2), []);
function initMap() {
  var pyrmont = {lat: -33.867, lng: 151.195};

  map = new google.maps.Map(document.getElementById('map'), {
    center: pyrmont,
    zoom: 15
  });

  infowindow = new google.maps.InfoWindow();

  var service = new google.maps.places.PlacesService(map);
  service.nearbySearch({
    location: pyrmont,
    radius: 500,
    types: ['store']
  }, callback);
}

function callback(results, status) {
  if (status === google.maps.places.PlacesServiceStatus.OK) {
    for (var i = 0; i < results.length; i++) {
      createMarker(results[i]);
    }
  }
  for (var key in allPlaces)
  	  console.log(key);
}

function createMarker(place) {
  var placeLoc = place.geometry.location;
  var marker = new google.maps.Marker({
    map: map,
    position: place.geometry.location,
    menu: new Menu(
    					place.name,
    					place.price_level,
    					new Entity(
    						[],
    						[allVulns[chance.natural({min:0,max:allVulns.length})]],
    						[],
    						[allDefs[chance.natural({min:0,max:allDefs.length})]]
    					)
    				)
    				
  });

  google.maps.event.addListener(marker, 'click', function() {
    infowindow.setContent(menuHTMLFactory(marker.menu.name));
    infowindow.open(map, this);
  });
  allPlaces[place.name] = marker;
}

function Menu(name, money, entity){
	this.name = name;
	this.money = money;
	this.entity = entity;
}

function menuHTMLFactory(name){
	return "<div>" +
			name + 
			": <span onClick = 'alert(contest(player, allPlaces[\"" +
			name +
			"\"].menu.entity));'> attack </span> </div>"
}

function contest(attack, defense){
	for(each of attack.offVulns){
			if(defense.defVulns.indexOf(each) != -1){
				for(which of defense.defDefs){
						if(!attack.offDefs.indexOf(which) == -1)
							return false;
				}
			}
			return true;
	}
	return false;
}